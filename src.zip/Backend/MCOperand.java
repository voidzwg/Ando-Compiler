package Backend;

public interface MCOperand {

}
