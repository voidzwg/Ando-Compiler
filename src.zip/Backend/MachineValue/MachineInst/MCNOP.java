package Backend.MachineValue.MachineInst;

public class MCNOP extends MCInst{


    @Override
    public String toString() {
        return "nop";
    }
}
