package Frontend.AST;

public abstract class BaseAST {
}
