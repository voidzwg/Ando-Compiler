package Frontend.AST;

public class ContinueAST {
}
