package IR.Type;

public class VoidType extends Type{

    @Override
    public boolean isVoidTy(){
        return true;
    }
}
