package IR.Type;

public class LabelType extends Type{

    @Override
    public boolean isLabelTy(){
        return true;
    }
}
