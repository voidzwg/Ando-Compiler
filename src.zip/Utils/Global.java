package Utils;

public class Global {
    public static String inputFile = "testfile.txt";
    public static String outputFile = "output.txt";
    public static String errorFile = "error.txt";
}
