package Utils;

public class Global {
    public static String inputFile = "testfile.txt";
    public static String iroutFile = "irout.txt";
    public static String outputFile = "mips.txt";
    public static String errorFile = "error.txt";
}
